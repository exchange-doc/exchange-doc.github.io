package com.chainup.controller;

import com.alibaba.fastjson.JSON;
import com.chainup.common.constant.StringConstant;
import com.chainup.common.enums.ExceptionEnum;
import com.chainup.common.util.HttpConnectUtil;
import com.chainup.common.util.MD5;
import com.chainup.common.util.SignUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.UnsupportedEncodingException;
import java.util.*;

/**
 * peter
 */
@Api(value = "接口管理", description = "接口管理",tags = {"公共接口"})
@Validated
@RestController
public class ConmonController {

    private  static Logger logger = LoggerFactory.getLogger(ConmonController.class);
    private static final String SECRET = "secret";
    private static final String APPKEY = "appKey";
    private static final String SIGN = "sign";
    private static final String TIME = "time";


    @PostMapping("/chainup/otc/coin/price")
    @ApiOperation(value = "查询报价接口",notes = "查询报价接口")
    public String price(){
        String jsonString = null;
        try {
            Long time = System.currentTimeMillis();
            Map<String,Object> params = new HashMap<>();
            params.put("symbol","USDT");
            params.put("payCoin","CNY");
            params.put("side","BUY");
            params.put("payType","PRICE");
            params.put("payPrice","60");
            params.put("payments","otc.payment.alipay,otc.payment.wxpay,otc.payment.domestic.bank.transfer");
            params.put("time", time);
            params.put(APPKEY, StringConstant.APPKEY);
            String sign = SignUtils.generateSign(params, StringConstant.APPKEY, StringConstant.APPSECRET, time);
            params.put(SIGN, sign);

            String httpResponse = HttpConnectUtil.postWithHead(StringConstant.URL+"/chainup/otc/coin/price", null,
                    JSON.toJSONString(params));
            logger.info(httpResponse);
        } catch (Exception e){
            logger.info("查询报价接口"+e);
            return ExceptionEnum.QUERY_LIMIT.getMsg();
        }
        return jsonString;
    }



    @PostMapping("/chainup/otc/floworder/merchant_account")
    @ApiOperation(value = "查询商户账户余额",notes = "查询商户账户余额")
    public String merchant_account(){
        Long time = System.currentTimeMillis();
        Map<String, Object> params = new HashMap<>();
        params.put("time", time);
        params.put(APPKEY, StringConstant.APPKEY);
        String sign = SignUtils.generateSign(params, StringConstant.APPKEY, StringConstant.APPSECRET, time);
        params.put(SIGN, sign);
        String jsonString = null;
        try {
            jsonString = HttpConnectUtil.postWithHead(StringConstant.URL+"/chainup/otc/floworder/merchant_account", null,
                    JSON.toJSONString(params));
        } catch (Exception e){
            logger.info("查询商户账户余额异常"+e);
            return ExceptionEnum.MERCHANT_ACCOUNT.getMsg();
        }
        return jsonString;
    }


    @PostMapping("/chainup/otc/floworder/query_user")
    @ApiOperation(value = "查询用户交易情况",notes = "查询用户交易情况")
    public String query_user(){
        Long time = System.currentTimeMillis();
        Map<String, Object> params = new HashMap<>();
        params.put("countryCode","86");
        params.put("mobileNumber","15701545003");
        params.put("time", time);
        params.put(APPKEY, StringConstant.APPKEY);
        String sign = SignUtils.generateSign(params, StringConstant.APPKEY, StringConstant.APPSECRET, time);
        params.put(SIGN, sign);
        String jsonString = null;
        try {
            jsonString = HttpConnectUtil.postWithHead(StringConstant.URL+"/chainup/otc/floworder/query_user", null,
                    JSON.toJSONString(params));
        } catch (Exception e){
            logger.info("查询用户交易情况"+e);
            return ExceptionEnum.QUERY_USER.getMsg();
        }
        return jsonString;
    }

    @PostMapping("/chainup/otc/floworder/query_order")
    @ApiOperation(value = "查询流动性订单详情",notes = "查询流动性订单详情")
    public String query_order(){
        Long time = System.currentTimeMillis();
        Map<String, Object> params = new HashMap<>();
        params.put("companyOrderNum","201911132209224b137bee");
        params.put("time", time);
        params.put(APPKEY, StringConstant.APPKEY);
        String sign = SignUtils.generateSign(params, StringConstant.APPKEY, StringConstant.APPSECRET, time);
        params.put(SIGN, sign);
        String jsonString = null;
        try {
            jsonString = HttpConnectUtil.postWithHead(StringConstant.URL+"/chainup/otc/floworder/query_order", null,
                    JSON.toJSONString(params));
        } catch (Exception e){
            logger.info("查询流动性订单详情"+e);
            return ExceptionEnum.QUERY_ORDER.getMsg();
        }
        return jsonString;
    }



    @PostMapping("/chainup/otc/floworder/trade_page")
    @ApiOperation(value = "开放平台订单详情展示",notes = "开放平台订单详情展示")
    public String trade_page(){
        Long time = System.currentTimeMillis();
        Map<String, Object> params = new HashMap<>();
        params.put("sequence","201911133010");//开放平台订单号
        params.put("outOrderId","201911132209224b137bee");//第三方调用平台订单号
        params.put("side","BUY");
        params.put("time", time);
        params.put(APPKEY, StringConstant.APPKEY);
        String sign = SignUtils.generateSign(params, StringConstant.APPKEY, StringConstant.APPSECRET, time);
        params.put(SIGN, sign);
        String jsonString = null;
        try {
            jsonString = HttpConnectUtil.postWithHead(StringConstant.URL+"/chainup/otc/floworder/trade_page", null,
                    JSON.toJSONString(params));
        } catch (Exception e){
            logger.info("开放平台订单详情展示"+e);
            return ExceptionEnum.QUERY_USER.getMsg();
        }
        return jsonString;
    }


}
