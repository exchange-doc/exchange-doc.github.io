package com.chainup.common.constant;

public interface StringConstant {

    //测试链接
    static final String  URL = "https://dev5open.chaindown.com/fe-platform-api";
//    static final String  URL = "http://localhost:8081";

    //测试KEY
    static final String  APPKEY = "lili";

    //测试私钥
    static final String  APPSECRET = "123456";

    //测试对冲账户uid
    static final String UID="10048";

}
