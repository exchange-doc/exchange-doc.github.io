package com.chainup.common.enums;

/**
 * Created by peter on 2018/08/16.
 * 异常枚举
 * 便于维护
 */
public enum ExceptionEnum {
    //系统异常
    SUCCESS(0, "成功"),
    UNKNOWN_ERROR(-1, "未知错误"),
    SYSTEM_ERROR(-2, "系统异常"),

    //错误
    QUERY_PRICE(40000, "查询USDT报价异常"),
    QUERY_LIMIT(40001, "查询支付方式交易限额异常"),
    MERCHANT_ACCOUNT(40002, "查询支付方式交易限额异常"),
    PRICE_COIN_NULL(40003,"货币标识不能为空"),
    QUERY_USER(40004, "查询用户交易情况异常"),
    QUERY_ORDER(40005, "查询订单异常"),
    SIGN_ERROR(40005, "签名异常"),

    ;

    private Integer code;

    private String msg;

    ExceptionEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }


    public static ExceptionEnum getCode(String param){
        for(ExceptionEnum exceptionEnum : ExceptionEnum.values()){
            String variable = exceptionEnum.toString().replaceAll("_", "");
            if(param.equalsIgnoreCase(variable)){
                return exceptionEnum;
            }
        }
        return ExceptionEnum.SYSTEM_ERROR;
    }

}