package com.chainup.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.util.Map;
import okhttp3.*;

import java.util.concurrent.TimeUnit;

public class HttpConnectUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(HttpConnectUtil.class);

    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    private static final String HTTP_PREFIX = "http://";

    private static OkHttpClient httpClient = new OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build();

    public static String getWithHead(String url, Map<String, String> headMap) throws IOException {
        Headers headers = Headers.of(headMap);
        Request request = new Request.Builder()
                .url(url)
                .headers(headers)
                .build();
        try (Response response = httpClient.newCall(request).execute()) {
            return response.body().string();
        }
    }

    public static String postWithHead(String url, Map<String, String> headerMap, String payload) {
        RequestBody body = RequestBody.create(JSON, payload == null ? "" : payload);
        return post(url, headerMap, body);
    }

    public static String postWithHead(String url, Map<String, String> headerMap, Map<String, String> paramMap,
                                      String payload) {
        okhttp3.FormBody.Builder builder = new okhttp3.FormBody.Builder();
        paramMap.forEach(builder::add);
        RequestBody body = builder.build();
        return post(url, headerMap, body);
    }



    public static String post(String url, Map<String, String> headerMap, RequestBody formBody) {

        Request.Builder builder = new Request.Builder()
                .url(url)
                .post(formBody);
        if (headerMap != null) {
            headerMap.forEach(builder::header);
        }

        Request request = builder.build();
        try (Response response = httpClient.newCall(request).execute()) {
            if (response.isSuccessful()) {
                ResponseBody body = response.body();
                return body == null ? "" : body.string();
            } else {
                ResponseBody body = response.body();
                return body == null ? response.message() : body.string();
            }
        } catch (Exception e) {
            LOGGER.error("post error url:{},headerMap:{},body:{},error:{}", url, headerMap, formBody, e);
        }
        return "";
    }


}
