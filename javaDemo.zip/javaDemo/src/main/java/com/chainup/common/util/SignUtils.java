package com.chainup.common.util;

import com.chainup.controller.ConmonController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.DigestUtils;

import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.TreeMap;

public class SignUtils {
    private  static Logger logger = LoggerFactory.getLogger(SignUtils.class);
    /**
     * 签名方法
     * @param requestMap
     * @param appkey
     * @param secret
     * @param now
     * @return
     */
    public static String generateSign(Map<String, Object> requestMap, String appkey, String secret, Long now){
        String sortParam = getSortParam(requestMap) + secret;
        String digest = null;
        try {
            digest = DigestUtils.md5DigestAsHex(sortParam.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            logger.error("generateSign error:", e);
        }
        return digest;
    }

    /**
     * 按照字母序将参数排序排序
     *
     * @param requestMap
     * @return
     */
    public static String getSortParam(Map<String, Object> requestMap) {
        Map<String, Object> map = new TreeMap<>(requestMap);
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            sb.append(entry.getKey()).append(entry.getValue());
        }
        return sb.toString();
    }
}
